
java -cp ./morpion-1.0.jar com.codingf.morpion.Morpion